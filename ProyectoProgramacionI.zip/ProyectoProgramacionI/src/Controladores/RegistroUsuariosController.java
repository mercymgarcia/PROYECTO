/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controladores;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.util.StringConverter;
import javax.swing.JOptionPane;


/**
 * FXML Controller class
 *
 * @author Sonia
 */
public class RegistroUsuariosController implements Initializable {

    @FXML
    private TextField txtEmailSignUp, txtUserSignUp;
    
    @FXML
    private PasswordField txtPassword, txtConfirmPassword;
    
    @FXML
    private ComboBox<Country> cbCountry;
    
    @FXML
    private Button btnInicioSesion, btnRegistrarse;
    
    
    private AccountsDAO modelAccount = new AccountsDAO();
    
    public void cleanFields(){
        txtEmailSignUp.setText("");
        txtPassword.setText("");
        txtConfirmPassword.setText("");
        txtUserSignUp.setText("");
               
    }
    
    @FXML
    public void keyEvent(KeyEvent e){
        
        String c = e.getCharacter();
        
        if(c.equalsIgnoreCase(" ")){
            e.consume();
        }
        
    }   
    
    @FXML
    public void actionEvent(ActionEvent e){
        
        Object evt = e.getSource();
        
        if(btnRegistrarse.equals(evt)){
        
            if(!txtEmailSignUp.getText().isEmpty() && !txtUserSignUp.getText().isEmpty() && 
               !txtConfirmPassword.getText().isEmpty() && !txtPassword.getText().isEmpty()){
                
                if(ControllerGeneralModel.validateEmail(txtEmailSignUp.getText())){
                    
                    if(txtUserSignUp.getText().length()>=3){

                            if(txtConfirmPassword.getText().equals(txtPassword.getText())){

                                Account account = new Account();
                                account.setEmail(txtEmailSignUp.getText());
                                account.setPassword(txtPassword.getText());
                                account.setUser(txtUserSignUp.getText());
                                

                                if(modelAccount.insertAccount(account)){

                                    JOptionPane.showMessageDialog(null, "El Usuario ha sido registrado de manera éxitosa", "OPERACIÓN ÉXITOSA", JOptionPane.INFORMATION_MESSAGE);
                                    cleanFields();

                                }else{

                                    if(EXCEPCIONES.size()>0){
                                        JOptionPane.showMessageDialog(null, "Surgieron errores en el proceso, posibles errores: \n"
                                                + ControllerGeneralModel.toString(EXCEPCIONES));
                                    }

                                }

                            }else{
                                JOptionPane.showMessageDialog(null, "Las contraseñas no coinciden, por favor verifique e intente nuevamente", "ERROR", JOptionPane.ERROR_MESSAGE);
                            }

                        }else{
                            JOptionPane.showMessageDialog(null, "Surgieron errores al conectar con la Base de Datos", "ERROR", JOptionPane.ERROR_MESSAGE);
                        }
                        
                    }else{
                        JOptionPane.showMessageDialog(null, "El Nombre de usuario debe contener al menos TRES caracteres", "ERROR", JOptionPane.ERROR_MESSAGE);                                                                                                       
                    }
                    
                }else{
                    
                    JOptionPane.showMessageDialog(null, "El Email que ha ingresado no es valido", "ERROR", JOptionPane.ERROR_MESSAGE);                                    
                
                }
                                
                
            }else{
                JOptionPane.showMessageDialog(null, "Debe llenar todos los campos obligatorios", "ERROR", JOptionPane.ERROR_MESSAGE);
            }                        
                                
        }
    
    }
    