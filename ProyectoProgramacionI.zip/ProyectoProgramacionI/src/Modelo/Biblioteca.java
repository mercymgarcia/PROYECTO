/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Vector;

/**
 *
 * @author Sonia
 */
public class Biblioteca {
    private Vector<Libro> libros;
    private Vector<Cliente> clientes;
    private Vector<Transaccion> transacciones;

    public Biblioteca() {
        libros = new Vector<>();
        clientes = new Vector<>();
        transacciones = new Vector<>();
    }

    public void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public void agregarTransaccion(Transaccion transaccion) {
        transacciones.add(transaccion);
    }

    public Vector<Libro> getLibros() {
        return libros;
    }

    public Vector<Cliente> getClientes() {
        return clientes;
    }

    public Vector<Transaccion> getTransacciones() {
        return transacciones;
    }

    public void exportarDatos(String archivo) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(libros);
            oos.writeObject(clientes);
            oos.writeObject(transacciones);
        }
    }

    public void importarDatos(String archivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            libros = (Vector<Libro>) ois.readObject();
            clientes = (Vector<Cliente>) ois.readObject();
            transacciones = (Vector<Transaccion>) ois.readObject();
        }
    }

    public String[][] transaccionesAMatriz() {
        String[][] matriz = new String[transacciones.size()][4];
        for (int i = 0; i < transacciones.size(); i++) {
            matriz[i] = transacciones.get(i).toMatrixRow();
        }
        return matriz;
    }

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();

        // Agregar algunos libros
        biblioteca.agregarLibro(new Libro("El Quijote", "Miguel de Cervantes", "1234567890"));
        biblioteca.agregarLibro(new Libro("Cien Años de Soledad", "Gabriel García Márquez", "0987654321"));

        // Agregar algunos clientes
        biblioteca.agregarCliente(new Cliente("Juan Pérez", "001"));
        biblioteca.agregarCliente(new Cliente("María López", "002"));

        // Agregar algunas transacciones
        biblioteca.agregarTransaccion(new Transaccion(biblioteca.getClientes().get(0), biblioteca.getLibros().get(0), new Date(), null));
        biblioteca.agregarTransaccion(new Transaccion(biblioteca.getClientes().get(1), biblioteca.getLibros().get(1), new Date(), null));

        // Exportar datos
        try {
            biblioteca.exportarDatos("biblioteca.dat");
            System.out.println("Datos exportados exitosamente.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Crear una nueva instancia de Biblioteca y importar datos
        Biblioteca nuevaBiblioteca = new Biblioteca();
        try {
            nuevaBiblioteca.importarDatos("biblioteca.dat");
            System.out.println("Datos importados exitosamente.");

            // Mostrar los datos importados
            System.out.println("\nLibros:");
            for (Libro libro : nuevaBiblioteca.getLibros()) {
                System.out.println(libro);
            }

            System.out.println("\nClientes:");
            for (Cliente cliente : nuevaBiblioteca.getClientes()) {
                System.out.println(cliente);
            }

            System.out.println("\nTransacciones:");
            for (Transaccion transaccion : nuevaBiblioteca.getTransacciones()) {
                System.out.println(transaccion);
            }

            // Convertir transacciones a matriz y mostrar
            String[][] matrizTransacciones = nuevaBiblioteca.transaccionesAMatriz();
            System.out.println("\nMatriz de Transacciones:");
            for (String[] fila : matrizTransacciones) {
                System.out.println(String.join(", ", fila));
            }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

//*
///utilizar 10.	Utilizar pilas o colas para manejar las transacciones de préstamo y devolución de libros de manera eficiente.
    private Queue<Transaccion> transacciones;

    public Biblioteca() {
        transacciones = new LinkedList<>();
    }

    public void agregarTransaccion(Transaccion transaccion) {
        transacciones.add(transaccion);
    }

    public Transaccion procesarSiguienteTransaccion() {
        return transacciones.poll(); // Devuelve y elimina la primera transacción de la cola
    }

    public void exportarDatos(String archivo) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(transacciones);
        }
    }

    public void importarDatos(String archivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            transacciones = (Queue<Transaccion>) ois.readObject();
        }
    }

    public void mostrarTransacciones() {
        for (Transaccion transaccion : transacciones) {
            System.out.println(transaccion);
        }
    }

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();

        // Crear algunos libros y clientes
        Libro libro1 = new Libro("El Quijote", "Miguel de Cervantes", "1234567890");
        Libro libro2 = new Libro("Cien Años de Soledad", "Gabriel García Márquez", "0987654321");

        Cliente cliente1 = new Cliente("Juan Pérez", "001");
        Cliente cliente2 = new Cliente("María López", "002");

        // Agregar algunas transacciones
        biblioteca.agregarTransaccion(new Transaccion(cliente1, libro1, new Date(), null));
        biblioteca.agregarTransaccion(new Transaccion(cliente2, libro2, new Date(), null));

        // Procesar la siguiente transacción
        Transaccion transaccionProcesada = biblioteca.procesarSiguienteTransaccion();
        System.out.println("Transacción procesada: " + transaccionProcesada);

        // Exportar datos
        try {
            biblioteca.exportarDatos("biblioteca.dat");
            System.out.println("Datos exportados exitosamente.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Crear una nueva instancia de Biblioteca y importar datos
        Biblioteca nuevaBiblioteca = new Biblioteca();
        try {
            nuevaBiblioteca.importarDatos("biblioteca.dat");
            System.out.println("Datos importados exitosamente.");

            // Mostrar los datos importados
            nuevaBiblioteca.mostrarTransacciones();

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

/**public class Biblioteca {
    
    //--------------------------------------------------------------------------
    //5.	Se deben utilizar vectores para almacenar la lista de libros y clientes.
    //import java.util.Vector; 

//public class Biblioteca {
    private Vector<Libro> libros;
    private Vector<Cliente> clientes;
    private Vector<Transaccion> transacciones;

    public Biblioteca() {
        libros = new Vector<>();
        clientes = new Vector<>();
        transacciones = new Vector<>();
    }
    
        public void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public void agregarTransaccion(Transaccion transaccion) {
        transacciones.add(transaccion);
    }

    public Vector<Libro> getLibros() {
        return libros;
    }

    public Vector<Cliente> getClientes() {
        return clientes;
    }

    public Vector<Transaccion> getTransacciones() {
        return transacciones;
    }

    }
// Métodos de exportación
    public void exportarDatos(String archivo) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(libros);
            oos.writeObject(clientes);
            oos.writeObject(transacciones);
        }
    }

    // Métodos de importación
    public void importarDatos(String archivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            libros = (Vector<Libro>) ois.readObject();
            clientes = (Vector<Cliente>) ois.readObject();
            transacciones = (Vector<Transaccion>) ois.readObject();
        }
    }

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();

        // Agregar algunos libros
        biblioteca.agregarLibro(new Libro("El Quijote", "Miguel de Cervantes", "1234567890"));
        biblioteca.agregarLibro(new Libro("Cien Años de Soledad", "Gabriel García Márquez", "0987654321"));

        // Agregar algunos clientes
        biblioteca.agregarCliente(new Cliente("Juan Pérez", "001"));
        biblioteca.agregarCliente(new Cliente("María López", "002"));

        // Agregar algunas transacciones
        biblioteca.agregarTransaccion(new Transaccion(biblioteca.getClientes().get(0), biblioteca.getLibros().get(0), new Date()));
        biblioteca.agregarTransaccion(new Transaccion(biblioteca.getClientes().get(1), biblioteca.getLibros().get(1), new Date()));

        // Exportar datos
        try {
            biblioteca.exportarDatos("biblioteca.dat");
            System.out.println("Datos exportados exitosamente.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Crear una nueva instancia de Biblioteca y importar datos
        Biblioteca nuevaBiblioteca = new Biblioteca();
        try {
            nuevaBiblioteca.importarDatos("biblioteca.dat");
            System.out.println("Datos importados exitosamente.");

            // Mostrar los datos importados
            System.out.println("\nLibros:");
            for (Libro libro : nuevaBiblioteca.getLibros()) {
                System.out.println(libro);
            }

            System.out.println("\nClientes:");
            for (Cliente cliente : nuevaBiblioteca.getClientes()) {
                System.out.println(cliente);
            }

            System.out.println("\nTransacciones:");
            for (Transaccion transaccion : nuevaBiblioteca.getTransacciones()) {
                System.out.println(transaccion);
            }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

        // Agregar algunos libros
        biblioteca.agregarLibro(new Libro("El Quijote", "Miguel de Cervantes", "1234567890"));
        biblioteca.agregarLibro(new Libro("Cien Años de Soledad", "Gabriel García Márquez", "0987654321"));

        // Agregar algunos clientes
        biblioteca.agregarCliente(new Cliente("Juan Pérez", "001"));
        biblioteca.agregarCliente(new Cliente("María López", "002"));

        // Mostrar libros y clientes
        System.out.println("Lista de Libros:");
        for (Libro libro : biblioteca.getLibros()) {
            System.out.println(libro);
        }

        System.out.println("\nLista de Clientes:");
        for (Cliente cliente : biblioteca.getClientes()) {
            System.out.println(cliente);
            
            
        //------------------------------------------------------------------

        // Agregar algunos libros
        biblioteca.agregarLibro(new Libro("El Quijote", "Miguel de Cervantes", "1234567890"));
        biblioteca.agregarLibro(new Libro("Cien Años de Soledad", "Gabriel García Márquez", "0987654321"));
        biblioteca.agregarLibro(new Libro("La Sombra del Viento", "Carlos Ruiz Zafón", "1122334455"));

        // Mostrar lista de libros antes de ordenar
        System.out.println("Lista de Libros antes de ordenar:");
        for (Libro libro : biblioteca.getLibros()) {
            System.out.println(libro);
        }

        // Ordenar por ISBN y mostrar
        biblioteca.ordenarPorISBN();
        System.out.println("\nLista de Libros ordenada por ISBN:");
        for (Libro libro : biblioteca.getLibros()) {
            System.out.println(libro);
        }

        // Ordenar por Título y mostrar
        biblioteca.ordenarPorTitulo();
        System.out.println("\nLista de Libros ordenada por Título:");
        for (Libro libro : biblioteca.getLibros()) {
            System.out.println(libro);
        }

        // Ordenar por Autor y mostrar
        biblioteca.ordenarPorAutor();
        System.out.println("\nLista de Libros ordenada por Autor:");
        for (Libro libro : biblioteca.getLibros()) {
            System.out.println(libro);
        }
        }
    }
 
//------------------------------------------------------------------------------
//6.	Se deben implementar algoritmos de ordenamiento para organizar la lista de libros por ISBN, título o autor.    
    // Métodos de ordenamiento
    public void ordenarPorISBN() {
        for (int i = 0; i < libros.size() - 1; i++) {
            for (int j = 0; j < libros.size() - 1 - i; j++) {
                if (libros.get(j).getIsbn().compareTo(libros.get(j + 1).getIsbn()) > 0) {
                    Libro temp = libros.get(j);
                    libros.set(j, libros.get(j + 1));
                    libros.set(j + 1, temp);
                }
            }
        }
    }

    public void ordenarPorTitulo() {
        for (int i = 0; i < libros.size() - 1; i++) {
            for (int j = 0; j < libros.size() - 1 - i; j++) {
                if (libros.get(j).getTitulo().compareTo(libros.get(j + 1).getTitulo()) > 0) {
                    Libro temp = libros.get(j);
                    libros.set(j, libros.get(j + 1));
                    libros.set(j + 1, temp);
                }
            }
        }
    }

    public void ordenarPorAutor() {
        for (int i = 0; i < libros.size() - 1; i++) {
            for (int j = 0; j < libros.size() - 1 - i; j++) {
                if (libros.get(j).getAutor().compareTo(libros.get(j + 1).getAutor()) > 0) {
                    Libro temp = libros.get(j);
                    libros.set(j, libros.get(j + 1));
                    libros.set(j + 1, temp);
                }
            }
        }
    }
}

//--------------------------------------------------------------------------------------------------------------------

import java.io.*;
import java.util.Vector;

public class Biblioteca {
    private Vector<Libro> libros;
    private Vector<Cliente> clientes;
    private Vector<Transaccion> transacciones;

    public Biblioteca() {
        libros = new Vector<>();
        clientes = new Vector<>();
        transacciones = new Vector<>();
    }

    public void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public void agregarTransaccion(Transaccion transaccion) {
        transacciones.add(transaccion);
    }

    public Vector<Libro> getLibros() {
        return libros;
    }

    public Vector<Cliente> getClientes() {
        return clientes;
    }

    public Vector<Transaccion> getTransacciones() {
        return transacciones;
    }

    // Métodos de exportación
    public void exportarDatos(String archivo) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(libros);
            oos.writeObject(clientes);
            oos.writeObject(transacciones);
        }
    }

    // Métodos de importación
    public void importarDatos(String archivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            libros = (Vector<Libro>) ois.readObject();
            clientes = (Vector<Cliente>) ois.readObject();
            transacciones = (Vector<Transaccion>) ois.readObject();
        }
    }

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();

        // Agregar algunos libros
        biblioteca.agregarLibro(new Libro("El Quijote", "Miguel de Cervantes", "1234567890"));
        biblioteca.agregarLibro(new Libro("Cien Años de Soledad", "Gabriel García Márquez", "0987654321"));

        // Agregar algunos clientes
        biblioteca.agregarCliente(new Cliente("Juan Pérez", "001"));
        biblioteca.agregarCliente(new Cliente("María López", "002"));

        // Agregar algunas transacciones
        biblioteca.agregarTransaccion(new Transaccion(biblioteca.getClientes().get(0), biblioteca.getLibros().get(0), new Date()));
        biblioteca.agregarTransaccion(new Transaccion(biblioteca.getClientes().get(1), biblioteca.getLibros().get(1), new Date()));

        // Exportar datos
        try {
            biblioteca.exportarDatos("biblioteca.dat");
            System.out.println("Datos exportados exitosamente.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Crear una nueva instancia de Biblioteca y importar datos
        Biblioteca nuevaBiblioteca = new Biblioteca();
        try {
            nuevaBiblioteca.importarDatos("biblioteca.dat");
            System.out.println("Datos importados exitosamente.");

            // Mostrar los datos importados
            System.out.println("\nLibros:");
            for (Libro libro : nuevaBiblioteca.getLibros()) {
                System.out.println(libro);
            }

            System.out.println("\nClientes:");
            for (Cliente cliente : nuevaBiblioteca.getClientes()) {
                System.out.println(cliente);
            }

            System.out.println("\nTransacciones:");
            for (Transaccion transaccion : nuevaBiblioteca.getTransacciones()) {
                System.out.println(transaccion);
            }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

*/

