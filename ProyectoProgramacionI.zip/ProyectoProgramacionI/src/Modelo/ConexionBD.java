/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import com.sun.jdi.connect.spi.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sonia
 */
public class ConexionBD {
    // Instancia única de la clase
    private static ConexionBD instancia;
    
    // Objeto Connection para la conexión a la base de datos
    private Connection conexion;
    
    // URL de la base de datos PostgreSQL
    private final String url = "postgres://dsyutqrt:720NuH8ewp4A4sOG829Nx2hPDxfEvQ52@bubble.db.elephantsql.com/dsyutqrt";
    
    // Propiedades para la conexión (usuario y ocntraseña)
    private Properties properties = new Properties();
    
    // Objeto estático de Connection
    private static java.sql.Connection conn = null;

    // Construcctor privado para evitar la instanciación desde fuera de la clase
    private ConexionBD () {
        // Establecer propiedades de usuario y contraseña
        properties.setProperty("user", "dsyutqrt");
        properties.setProperty("password", "720NuH8ewp4A4sOG829Nx2hPDxfEvQ52");
        
        try {
            // Intentar establecer la conexión a la base de datos
            conn = DriverManager.getConnection(url, properties);
        } catch (SQLException ex) {
            // Manejar cualquier excepción que ocurra durante la conexión
            Logger.getLogger(ConexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
    //Método estático para obtener la conexión
    public static java.sql.Connection getConnection() {
        // Si la conexión no ha sido creada, crear una nueva instancia de ConexionBDD
        if (conn == null) {
               ConexionBD c = new ConexionBD();
               return c.conn;
        }
        else {
            // Si ya existe una conexión, devolverla
            return conn ;
        }
    }
}
    
