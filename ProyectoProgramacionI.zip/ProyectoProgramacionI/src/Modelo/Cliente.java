/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import com.sun.jdi.connect.spi.Connection;

/**
 *
 * @author Sonia
 */
public class Cliente {
    
    //Conexion a base de dtos
    Connection conn;
        public Cliente(){
        conn = (Connection) ConexionBD.getConnection();
    }
          
    //5.	Se deben utilizar vectores para almacenar la lista de clientes.
    //APLICACION DEL PRINCIPIO DE ABSTRACCION DE POO 
    // APLICACION DEL PRINCIPIO DE ENCAPSULAMIENTO
    private static final long serialVersionUID = 1L;
    private String id_usuario;
    private String nombre_usuario;
    private String usuario;
    private String password_usuario;
    private String direccion_usuario;
    private Integer telefono_usuario;
    private String dpi_usuario;

//GETTERS DE LOS ATRIBUTOS QUE NOS PERMITEN ACCEDER A ELLOS PARA IMPLEMENTARLOS EN OTRAS CLASES
    public String getId_usuario() {
        return id_usuario;
    }

    public String getNombre_usuario() {
        return nombre_usuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getPassword_usuario() {
        return password_usuario;
    }

    public String getDireccion_usuario() {
        return direccion_usuario;
    }

    public Integer getTelefono_usuario() {
        return telefono_usuario;
    }

    public String getDpi_usuario() {
        return dpi_usuario;
    }
    

    @Override
    public String toString() {
        return "Cliente{" +
                "nombre='" + nombre_usuario + '\'' +
                ", id='" + id_usuario + '\'' +
                '}';
    }

    String getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}    

